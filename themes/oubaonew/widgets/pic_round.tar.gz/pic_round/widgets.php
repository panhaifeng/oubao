<?php
$setting['author']      = 'hnqss.cn';
$setting['version']     = '1.0.0';
$setting['order']       = 17;
$setting['name']        = '图片轮播';
$setting['catalog']     = '图片轮播';
$setting['description'] = '图片轮播 ';
$setting['usual']       = '0';
$setting['stime']       = '2014-03-26';
$setting['template']    = array(
    'default.html' => '默认',
);
?>